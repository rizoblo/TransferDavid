
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/styles.css')); ?>">
    <h1 class="fuenteTitulo text-center mt-5 mb-5">Editar Partido</h1>
    <div class="container w-50">
        <form action="" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="localTeamEditMatch" class="fuenteBlanca">Equipo Local:</label>
                <select class="form-control disabled" id="localTeamEditMatch" name="localTeamEditMatch" value="<?php echo e(old('localTeamEditMatch')); ?>" disabled>
                    <?php $__currentLoopData = $clubes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($club->id == $partidoAEditar->id_team_local): ?>
                            <option value="<?php echo e($club->id); ?>" selected="selected"><?php echo e($club->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($club->id); ?>" ><?php echo e($club->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="visitorTeamEditMatch" class="fuenteBlanca">Equipo Visitante:</label>
                <select class="form-control" id="visitorTeamEditMatch" name="visitorTeamEditMatch" value="<?php echo e(old('visitorTeamEditMatch')); ?>" disabled>
                    <?php $__currentLoopData = $clubes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($club->id == $partidoAEditar->id_team_visitor): ?>
                            <option value="<?php echo e($club->id); ?>" selected="selected"><?php echo e($club->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($club->id); ?>" ><?php echo e($club->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="scoreLocalEditMatch" class="fuenteBlanca">Marcador del local:</label>
                <input type="number" class="form-control" name="scoreLocalEditMatch" id="scoreLocalEditMatch" value="<?php echo e($partidoAEditar->score_local); ?>" min="0" required>
            </div>
            <div class="form-group">
                <label for="scoreVisitorEditMatch" class="fuenteBlanca">Marcador del visitante:</label>
                <input type="number" class="form-control" name="scoreVisitorEditMatch" id="scoreVisitorEditMatch" value="<?php echo e($partidoAEditar->score_visitor); ?>" min="0" required>
            </div>
            <input type="hidden" value="<?php echo e($partidoAEditar->id); ?>" name="guardarIdEditMatch">
            <button class="btn btn-success" type="submit" name="guardarEditMatch">Guardar</button>
        </form>
        <br>
        <a href="<?php echo e(url('/deleteMatch/'.$partidoAEditar->id)); ?>"><button class="btn btn-danger" name="eliminarEditMatch">Eliminar</button></a>
        <br>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hojbdyav/laravel/resources/views/editMatch.blade.php ENDPATH**/ ?>