<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/styles.css')); ?>">
    <div class="col-md-12 text-center text-light">
        <h1 class="fuenteTitulo mt-5 mb-5 backGroundCabeceras"><img style="border-radius: 10%" src="../images/ligas/santander.png"> Liga Santander</h1>
        <div class="container">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-4 mt-3 justify-content-start" >
                        <form action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="selectCompeticiones">Seleccione temporada:</label>
                                <select class="form-control text-white bg-info" style="width: 350px" id="selectCompeticiones" name="selectCompeticiones" value="<?php echo e(old('selectCompeticiones')); ?>">
                                    <?php $__currentLoopData = $ligas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($ligaSeleccionada==$liga->id): ?>
                                            <option value="<?php echo e($liga->id); ?>" selected="selected"><?php echo e($liga->name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($liga->id); ?>"><?php echo e($liga->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button class="btn btn-info mt-3" type="submit" name="filtrar">Filtrar</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="row mt-3 margenCP">
                    <div class="col-md-12 table-responsive">
                        <table class="table table-bordered fuenteBlanca ">
                            <thead class="thead-light">
                            <tr>
                                <th scope="col">Posición</th>
                                <th scope="col" colspan="2">Club</th>
                                <th scope="col">PJ</th>
                                <th scope="col">V</th>
                                <th scope="col">E</th>
                                <th scope="col">D</th>
                                <th scope="col">GF</th>
                                <th scope="col">GC</th>
                                <th scope="col">DG</th>
                                <th scope="col">Puntos</th>
                            </tr>
                            </thead>
                            <tbody>

                                    <?php $__currentLoopData = $partidosLiga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($contador=$contador +1); ?></th>
                                            <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($partido->image)); ?>"></td>
                                            <td><?php echo e($partido->name); ?></td>
                                            <td><?php echo e($partido->pj); ?></td>
                                            <td><?php echo e($partido->v); ?></td>
                                            <td><?php echo e($partido->e); ?></td>
                                            <td><?php echo e($partido->d); ?></td>
                                            <td><?php echo e($partido->gf); ?></td>
                                            <td><?php echo e($partido->gc); ?></td>
                                            <td><?php echo e($partido->dg); ?></td>
                                            <td><?php echo e($partido->points); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TransferDavid\resources\views/ligaSantander.blade.php ENDPATH**/ ?>