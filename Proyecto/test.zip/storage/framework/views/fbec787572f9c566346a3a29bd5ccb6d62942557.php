
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/styles.css')); ?>">
    <div class="col-md-12 justify-content-center text-center">
        <h1 class="fuenteTitulo mt-5 mb-5 backGroundCabeceras">Jugadores</h1>
        <div class="container">
            <div class="col-md-12">
                <div class="row mt-3">
                    <div class="col-md-3"></div>
                    <div class="col-md-9">
                        <div class="form-group">
                            <form action="" method="POST" class="estilosFormFiltrarJugador">
                                <?php echo csrf_field(); ?>
                                <label for="busquedaJugador" class="fuenteBlanca">Busque su jugador</label>
                                <input type="text" class="form-control inpJug bg-info" placeholder="Busque su jugador" name="nameFindPlayer">
                                <label for="selectEquipo" class="fuenteBlanca">Seleccione Equipo</label>
                                <select class="form-control text-white bg-info" id="selectEquipo" name="teamFindPlayer">
                                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <option selected="selected">Todos</option>
                                </select>
                                <label for="selectPosicion" class="fuenteBlanca">Seleccione Posición</label>
                                <select class="form-control text-white bg-info" id="positionFindPlayer" name="positionFindPlayer">
                                    <option>Delantero</option>
                                    <option>Centrocampista</option>
                                    <option>Defensa</option>
                                    <option>Portero</option>
                                    <option selected="selected">Todas</option>
                                </select>
                                <input type="submit" class="btn btn-info mt-1" value="Buscar">
                            </form>
                        </div>
                    </div>
                    <div class="col-md-3"></div>

                </div>

                <div class="row mt-3">
                    <?php $__currentLoopData = $jugadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jugador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mt-5" style="background-color: rgba(0, 233, 255, 0.8);padding-right: 0px !important;padding-left: 0px !important;)">
                        <div class="row">
                            <div class="col-md-1  colorHueco"></div>
                            <div class="col-md-3 " style="border: 1px solid black;">
                                <img  class="img-fluid margenesJugador" src="<?php echo e($jugador->player_image); ?>" alt="Card image cap">
                            </div>
                            <div class="col-md-4" style="border: 1px solid black;">
                                <h6 class="fuenteBlanca mt-4" >Posición: <?php echo e($jugador->position); ?></h6>
                                <h6 class="fuenteOscura mt-4" ><?php echo e($jugador->name); ?> <?php echo e($jugador->last_name); ?></h6>
                                <p class="fuenteBlanca mt-4" >Valor de mercado: <span class="fuenteOscura"><?php echo e($jugador->value); ?>€</span></p>
                            </div>
                            <div class="col-md-3 " style="border: 1px solid black;">
                                <img class="img-fluid margenesEquipo" src="<?php echo e($jugador->image); ?>" alt="Card image cap">
                            </div>
                            <div class="col-md-1  colorHueco"></div>
                        </div>
                        <div class="row">
                            <div class="col-md-1 colorHueco"></div>
                            <div class="col-md-10">
                                <form action="" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <?php if(Auth()->check()): ?>
                                        <?php if(Auth()->user()->role!="Estándar"): ?>
                                            <a class="btn btn-success" href="<?php echo e(url('/editarJugadores/'.$jugador->id)); ?>">Editar</a>
                                            <a class="btn btn-danger" style="color:white" href="<?php echo e(url("/jugadoresEliminar/".$jugador->id)); ?>">Eliminar</a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a class="btn btn-success disabled" href="<?php echo e(url('/editarJugadores/'.$jugador->id)); ?>">Editar</a>
                                        <a class="btn btn-danger disabled" style="color:white" href="<?php echo e(url("/jugadoresEliminar/".$jugador->id)); ?>">Eliminar</a>
                                    <?php endif; ?>
                                </form>
                            </div>
                            <div class="col-md-1  colorHueco"></div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hojbdyav/laravel/resources/views/jugadores.blade.php ENDPATH**/ ?>