<?php $__env->startSection('content'); ?>
<div class="container justify-content-center text-center">
    <h2 class="titulo fuenteTitulo  mt-5">Tu rol: <?php echo e(Auth()->user()->role); ?></h2>
    <div class="col-lg-12 margenCajaAdministration">
        <div class="row">
            <div class="col-lg-3">
                <ul class="acorh">
                    <li><a href="#">EQUIPOS</a>
                        <ul>
                            <li><a href="<?php echo e(url('/clubes')); ?>">Ver equipos</a></li>
                            <li><a href="<?php echo e(url('/addTeam')); ?>">Añadir equipos</a></li>
                        </ul>
                    </li>
                    <li><a href="#">JUGADOR</a>
                        <ul>
                            <li><a href="<?php echo e(url('/jugadores')); ?>">Ver jugadores</a></li>
                            <li><a href="<?php echo e(url('/addPlayer')); ?>">Añadir jugadores</a></li>
                        </ul>
                    </li>
                    <li><a href="#">NOTICIAS</a>
                        <ul>
                            <li><a href="<?php echo e(url('/')); ?>">Ver noticias</a></li>
                            <li><a href="<?php echo e(url('/addNotice')); ?>">Añadir noticias</a></li>
                        </ul>
                    </li>
                    <li><a href="#">PARTIDOS</a>
                        <ul>
                            <li><a href="<?php echo e(url('/matches')); ?>">Ver partidos</a></li>
                            <?php if(Auth()->user()->role=="Creador"): ?>
                                <li><a href="" style="background-color: red !important;">Añadir partido</a></li>
                            <?php else: ?>
                                <li><a href="<?php echo e(url('/addMatch/false')); ?>">Añadir partido</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="col-lg-9">
                <div class="col-lg-12 table-responsive" style="margin-top: 2%;margin-bottom: 10%">
                    <table class="table table-bordered fuenteBlanca">
                        <?php $__currentLoopData = $arrayUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <thead class="thead-light">
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Email</th>
                                <th scope="col">Equipo Favorito</th>
                                <th scope="col">Rol</th>
                                <th scope="col" colspan="2">Acciones</th>
                            </tr>
                            </thead>
                            <tbody>
                            <th scope="row"><?php echo e($user->id); ?></th>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($team->id == $user->fav_team): ?>
                                    <td><?php echo e($team->name); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($user->role); ?></td>
                            <td>
                                <?php if(Auth()->user()->role=="Creador"): ?>
                                    <a href="<?php echo e(url('/editUser/'.$user->id.'/admin')); ?>" class="btn btn-warning disabled" disabled>Editar</a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/editUser/'.$user->id.'/admin')); ?>" class="btn btn-warning">Editar</a>
                                <?php endif; ?>

                            </td>
                            <td>
                                <?php if(Auth()->user()->role=="Creador"): ?>
                                <a href="<?php echo e(url('/deleteUser/'.$user->id.'/admin')); ?>" class="btn btn-danger disabled" disabled>Eliminar</a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('/deleteUser/'.$user->id.'/admin')); ?>" class="btn btn-danger">Eliminar</a>
                                <?php endif; ?>
                            </td>
                            </tbody>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TransferDavid\resources\views/administration.blade.php ENDPATH**/ ?>