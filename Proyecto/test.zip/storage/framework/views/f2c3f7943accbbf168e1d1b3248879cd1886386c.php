
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/css/styles.css')); ?>">
    <div class="container text-center justify-content-center" style="background-image: url(<?php echo e(asset($team->wallpaper)); ?>) !important;
    background-repeat: no-repeat;background-size: 100% 100%;">
        <div class="col-md-12 mt-5 mb-5">
            <div class="row prueba2">
                <div class="col-md-9 mt-5 mb-5 cajaJugadores">
                   <div class="row prueba2">
                       <?php $__currentLoopData = $jugadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jugador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="col-md-6 mt-5">
                           <div class="row">
                                   <div class="col-md-1 colorHueco2 heightMinimoColumnasJugadoresShowTeam"></div>
                                   <div class="col-md-3 colorHueco3 heightMinimoColumnasJugadoresShowTeam">
                                       <img  class="img-fluid margenesJugador2" src="<?php echo e(asset($jugador->player_image)); ?>" alt="Card image cap">
                                   </div>
                                   <div class="col-md-4 colorHueco3 heightMinimoColumnasJugadoresShowTeam">
                                       <h6 class="fuenteBlanca mt-4" >Posición: <?php echo e($jugador->position); ?></h6>
                                       <h6 class="fuenteOscura mt-4" ><?php echo e($jugador->name); ?> <?php echo e($jugador->last_name); ?></h6>
                                       <p class="fuenteBlanca mt-4" >Valor de mercado: <span class="fuenteOscura"><?php echo e($jugador->value); ?>€</span></p>
                                   </div>
                                   <div class="col-md-3 colorHueco3 heightMinimoColumnasJugadoresShowTeam">
                                       <img class="img-fluid margenesEquipo2" src="<?php echo e(asset($jugador->image)); ?>" alt="Card image cap">
                                   </div>
                                   <div class="col-md-1 colorHueco2 heightMinimoColumnasJugadoresShowTeam"></div>
                           </div>
                           <div class="row">
                               <div class="col-md-12">
                                   <?php if(Auth::check()): ?>
                                       <?php if(Auth()->user()->role!="Estándar"): ?>
                                           <a class="btn btn-success" style="color:white" href="<?php echo e(url('/editarJugadores/'.$jugador->id)); ?>" >Editar</a>
                                           <a class="btn btn-danger" href="<?php echo e(url("/jugadoresEliminar/".$jugador->id)); ?>" >Eliminar</a>
                                       <?php endif; ?>
                                   <?php else: ?>
                                       <a class="btn btn-success disabled" style="color:white" href="<?php echo e(url('/editarJugadores/'.$jugador->id)); ?>">Editar</a>
                                       <a class="btn btn-danger disabled" href="<?php echo e(url("/jugadoresEliminar/".$jugador->id)); ?>">Eliminar</a>
                                   <?php endif; ?>
                               </div>
                           </div>
                       </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
                </div>
                <div class="col-md-3 mt-5">
                    <div class="card">
                        <img class="card-img-top mt-3" src="<?php echo e(asset($team->image)); ?>" style="margin-left: 35%;margin-right: 35%;width: 30%" alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title"><b><?php echo e($team->name); ?></b></h5>
                            <p class="card-text text-left textAreaInfoClub"><i><?php echo e($team->review); ?></i></p>
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Fundación: <?php echo e($team->fundation); ?></li>
                            <li class="list-group-item">Estadio: <?php echo e($team->stadium); ?></li>
                            <li class="list-group-item">Entrenador: <?php echo e($team->coach); ?></li>
                            <?php if($team->nationality=="España"): ?>
                                <li class="list-group-item">Nacionalidad: <img style="width: 20%" src="<?php echo e(asset('images/paises/spain.png')); ?>"></li>
                            <?php endif; ?>
                            <?php if($team->nationality=="Francia"): ?>
                                <li class="list-group-item">Nacionalidad: <img style="width: 20%" src="<?php echo e(asset('images/paises/francia.png')); ?>"></li>
                            <?php endif; ?>
                            <?php if($team->nationality=="Reino Unido"): ?>
                                <li class="list-group-item">Nacionalidad: <img style="width: 20%" src="<?php echo e(asset('images/paises/uk.png')); ?>"></li>
                            <?php endif; ?>
                            <?php if($team->nationality=="Alemania"): ?>
                                <li class="list-group-item">Nacionalidad: <img style="width: 20%" src="<?php echo e(asset('images/paises/alemania.png')); ?>"></li>
                            <?php endif; ?>
                            <?php if($team->nationality=="Italia"): ?>
                                <li class="list-group-item">Nacionalidad: <img style="width: 20%" src="<?php echo e(asset('images/paises/italia.png')); ?>"></li>
                            <?php endif; ?>

                        </ul>
                        <div class="card-body">
                            <a target="_blank" href="<?php echo e($team->web); ?>" class="card-link">Web Oficial</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hojbdyav/laravel/resources/views/showTeam.blade.php ENDPATH**/ ?>