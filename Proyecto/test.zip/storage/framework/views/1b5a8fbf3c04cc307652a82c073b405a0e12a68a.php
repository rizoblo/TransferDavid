
<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/css/styles.css')); ?>">
    <div class="container overflowPers text-white justify-content-center ">

        <?php if($equipoSeleccionado=="madrid"): ?>
            <h1 class="fuenteTitulo text-center mt-3 mb-1">Partidos del Real Madrid</h1>
        <?php else: ?>
            <h1 class="fuenteTitulo text-center mt-3 mb-1">Partidos del F.C Barcelona</h1>
        <?php endif; ?>

        <div class="col-md-12">
            <div class="row">
                <div class="col-md-4 mt-3 justify-content-start" >
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="selectCompeticiones">Escoja competición:</label>
                            <select class="form-control text-white bg-info" style="width: 350px" id="selectCompeticiones" name="selectCompeticiones">
                                <?php $__currentLoopData = $ligas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($ligaSeleccionada)): ?>
                                        <?php if($ligaSeleccionada==$liga->id): ?>
                                            <option value="<?php echo e($liga->id); ?>" selected="selected"><?php echo e($liga->name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($liga->id); ?>"><?php echo e($liga->name); ?></option>
                                        <?php endif; ?>
                                        <?php else: ?>
                                        <option value="<?php echo e($liga->id); ?>"><?php echo e($liga->name); ?></option>
                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button class="btn btn-info mt-3" type="submit" name="filtrar">Filtrar</button>
                        </div>
                    </form>
                    <?php if(Auth()->check()): ?>
                        <?php if($equipoSeleccionado=="madrid" && Auth()->user()->role=="Administrador"): ?>
                            <a href="<?php echo e(url('/addMatch/false/madrid')); ?>"><button class="btn btn-info mb-4" type="submit" name="filtrar">Añadir Partido</button></a>
                        <?php endif; ?>
                        <?php if($equipoSeleccionado=="barcelona" && Auth()->user()->role=="Administrador"): ?>
                            <a href="<?php echo e(url('/addMatch/false/barcelona')); ?>"><button class="btn btn-info mb-4" type="submit" name="filtrar">Añadir Partido</button></a>
                        <?php endif; ?>
                    <?php endif; ?>


                </div>
            </div>
            <div class="row cajaMatchesInfo mt-5 margenCP">
                <div class="col-md-12 table-responsive">
                    <table class="table table-bordered fuenteBlanca mt-5">
                        <thead class="thead-light">
                        <tr class="text-center">
                            <th scope="col">Jornada</th>
                            <th scope="col" colspan="2">Local</th>
                            <th scope="col" colspan="3">Resultado</th>
                            <th scope="col" colspan="2">Visitante</th>
                            <th scope="col">Edición</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $arrayPartidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$partido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <?php if($equipoSeleccionado=="madrid"): ?>

                                        <td><?php echo e($partido->journey); ?></td>

                                    <?php if($partido->id_team_local!=$idMadrid): ?>
                                            <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($infoContrincantes[$key][0]->image)); ?>"></td>
                                            <td><?php echo e($infoContrincantes[$key][0]->name); ?></td>
                                        <?php else: ?>
                                            <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($partido->image)); ?>"></td>
                                            <td><?php echo e($partido->name); ?></td>
                                        <?php endif; ?>
                                        <td style="font-size: 30px" colspan="3"><?php echo e($partido->score_local); ?> - <?php echo e($partido->score_visitor); ?></td>
                                        <?php if($partido->id_team_visitor!=$idMadrid): ?>
                                            <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($infoContrincantes[$key][0]->image)); ?>"></td>
                                            <td><?php echo e($infoContrincantes[$key][0]->name); ?></td>
                                        <?php else: ?>
                                            <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($partido->image)); ?>"></td>
                                            <td><?php echo e($partido->name); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($equipoSeleccionado=="barcelona"): ?>
                                            <td><?php echo e($partido->journey); ?></td>

                                        <?php if($partido->id_team_local!=$idBarcelona): ?>
                                            <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($infoContrincantes[$key][0]->image)); ?>"></td>
                                            <td><?php echo e($infoContrincantes[$key][0]->name); ?></td>
                                        <?php else: ?>
                                            <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($partido->image)); ?>"></td>
                                            <td><?php echo e($partido->name); ?></td>
                                        <?php endif; ?>
                                        <td style="font-size: 30px" colspan="3"><?php echo e($partido->score_local); ?> - <?php echo e($partido->score_visitor); ?></td>
                                        <?php if($partido->id_team_visitor!=$idBarcelona): ?>
                                            <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($infoContrincantes[$key][0]->image)); ?>"></td>
                                            <td><?php echo e($infoContrincantes[$key][0]->name); ?></td>
                                        <?php else: ?>
                                            <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($partido->image)); ?>"></td>
                                            <td><?php echo e($partido->name); ?></td>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <td>
                                        <form action="<?php echo e(url('/editMatch')); ?>" method="POST" name="editarPartidoList">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" value="<?php echo e($partido->id); ?>" name="guardarIdPartidoEditar">
                                            <?php if(Auth()->check()): ?>
                                                <?php if(Auth()->user()->role=="Administrador"): ?>
                                                    <button type="submit" class="btn btn-warning">Editar</button>
                                                <?php else: ?>
                                                    <button type="submit" class="btn btn-warning disabled" disabled>Editar</button>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <button type="submit" class="btn btn-warning disabled" disabled>Editar</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hojbdyav/laravel/resources/views/matchesList.blade.php ENDPATH**/ ?>