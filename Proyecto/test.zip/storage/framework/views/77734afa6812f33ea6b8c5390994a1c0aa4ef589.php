<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/styles.css')); ?>">
        <h1 class="fuenteTitulo text-center mt-5">Todos los Usuarios</h1>
        <div class="col-md-12 text-center">
            <div class="container">
                <div class="col-md-12">
                    <div class="row mt-3">
                        <div class="col-md-12 table-responsive" style="margin-top: 5%;margin-bottom: 10%">
                            <table class="table table-bordered fuenteBlanca">
                            <?php $__currentLoopData = $arrayUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <thead class="thead-light">
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Nombre</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Equipo Favorito</th>
                                        <th scope="col">Rol</th>
                                        <th scope="col" colspan="2">Acciones</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <th scope="row"><?php echo e($user->id); ?></th>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($team->id == $user->fav_team): ?>
                                                <td><?php echo e($team->name); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($user->role); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/editUser/'.$user->id.'/admin')); ?>" class="btn btn-warning">Editar</a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('/deleteUser/'.$user->id.'/admin')); ?>" class="btn btn-danger">Eliminar</a>
                                        </td>
                                    </tbody>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TransferDavid\resources\views/adminUsers.blade.php ENDPATH**/ ?>