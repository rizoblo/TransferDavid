<?php $__env->startSection('content'); ?>
    <h1 class="fuenteTitulo text-center mt-5 mb-5">Editar Jugador</h1>
    <div class="container w-50">
        <form action="" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="namePlayer" class="fuenteBlanca">Nombre del Jugador:</label>
                <input type="text" class="form-control" name="namePlayerEdit" id="namePlayer" value="<?php echo e($jugadorAEditar->name); ?>" placeholder="Escriba el nombre del Jugador" required>
            </div>
            <div class="form-group">
                <label for="lastnamePlayer" class="fuenteBlanca">Apellido del Jugador:</label>
                <input type="text" class="form-control" name="lastnamePlayerEdit" id="lastnamePlayer" value="<?php echo e($jugadorAEditar->last_name); ?>" placeholder="Escriba el apellido del Jugador" required>
            </div>
            <div class="form-group">
                <label for="valuePlayer" class="fuenteBlanca">Valor de Mercado:</label>
                <input type="number" class="form-control" name="valuePlayerEdit" id="valuePlayer" value="<?php echo e($jugadorAEditar->value); ?>" placeholder="Inserte valor del Jugador" min="0" required>
            </div>
            <div class="form-group">
                <label for="positionPlayer" class="fuenteBlanca">Posición del Jugador:</label>
                <select class="form-control" id="positionPlayer" name="positionPlayerEdit" value="<?php echo e($jugadorAEditar->position); ?>" required>
                    <?php if($jugadorAEditar->position == "Delantero"): ?>
                        <option selected="selected">Delantero</option>
                    <?php else: ?>
                        <option>Delantero</option>
                    <?php endif; ?>
                    <?php if($jugadorAEditar->position == "Centrocampista"): ?>
                        <option selected="selected">Centrocampista</option>
                    <?php else: ?>
                        <option>Centrocampista</option>
                    <?php endif; ?>
                    <?php if($jugadorAEditar->position == "Defensa"): ?>
                        <option selected="selected">Defensa</option>
                    <?php else: ?>
                        <option>Defensa</option>
                    <?php endif; ?>
                    <?php if($jugadorAEditar->position == "Portero"): ?>
                        <option selected="selected">Portero</option>
                    <?php else: ?>
                        <option>Portero</option>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="teamPlayer" class="fuenteBlanca">Equipo del Jugador:</label>
                <select class="form-control" id="teamPlayer" name="teamPlayerEdit" required>
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($jugadorAEditar->id_team == $team->id): ?>
                            <option value="<?php echo e($team->id); ?>" selected="selected"><?php echo e($team->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="image" class="fuenteBlanca">Seleccione la imagen del Jugador:</label><br>
                <input type="file" class="fuenteBlanca" class="form-control-file" id="image" name="image" accept="image/*">
            </div>
            <button class="btn btn-success" type="submit" name="guardar">Guardar</button>
        </form>
        <br>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TransferDavid\resources\views/editPlayer.blade.php ENDPATH**/ ?>