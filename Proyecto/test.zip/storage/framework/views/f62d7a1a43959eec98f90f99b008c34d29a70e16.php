<nav class="navbar navbar-expand-lg navbar-dark bg-info">
    <a class="navbar-brand" href="<?php echo e(url("/")); ?>">TRANSFERDAVID</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link espaciado1 colorNavLink"  href="<?php echo e(url("/jugadores")); ?>">JUGADORES</a>
            </li>
            <li class="nav-item">
                <a class="nav-link espaciado1 colorNavLink"  href="<?php echo e(url("/clubes")); ?>">CLUBES</a>
            </li>
            <li class="nav-item">
                <a class="nav-link espaciado1 colorNavLink"  href="<?php echo e(url("/matches")); ?>">PARTIDOS</a>
            </li>
            <li class="nav-item dropdown " style="min-width: 6rem !important;">
                <a class="nav-link dropdown-toggle espaciado1 espaciado3 colorNavLink" id="estilosMenuPerfil" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">LIGAS</a>
                <div class="dropdown-menu" style="background-color: #343a40" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item espaciado2 colorNavLink" style="background-color: #343a40;color:white;" href="<?php echo e(url("/league/1")); ?>">Liga Santander</a>
                    <div class="dropdown-divider"></div>
                    <!--<a class="dropdown-item espaciado2 colorNavLink" style="background-color: #343a40;color:white;" href="<?php echo e(url("/league/3")); ?>">Premier League</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item espaciado2 colorNavLink" style="background-color: #343a40;color:white;" href="<?php echo e(url("/league/4")); ?>">Serie A</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item espaciado2 colorNavLink" style="background-color: #343a40;color:white;" href="<?php echo e(url("/league/5")); ?>">Bundesliga</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item espaciado2 colorNavLink" style="background-color: #343a40;color:white;" href="<?php echo e(url("/league/6")); ?>">Ligue 1</a>-->
                </div>
            </li>

            <?php if(Auth::check() && Auth()->user()->role != "Estándar"): ?>
                <!--<li class="nav-item">
                    <a class="nav-link"  href="<?php echo e(url("/adminUsers")); ?>">Administrar Usuarios</a>
                </li>-->
                <li class="nav-item">
                    <a class="nav-link espaciado1 colorNavLink"  href="<?php echo e(url("/administration")); ?>">Administrar</a>
                </li>

            <?php endif; ?>

        </ul>
        <!--GESTION BOTON INICIO DE SESION-->
        <?php if(Auth::check()): ?>
            <li class="nav-item dropdown estiloNombreUsu">
                <a class="nav-link dropdown-toggle tamanioMovil1" style="border:1px solid white;border-radius: 15%;" href="#" id="menuPerfil" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo e(Auth()->user()->name); ?>

                </a>
                <div class="dropdown-menu mt-2" style="background-color: #17a2b8" aria-labelledby="navbarDropdown">
                    <form action="<?php echo e(url('/editUser/'.Auth()->user()->id.'/noAdmin')); ?>" class="form-inline justify-content-center" method="POST">
                        <?php echo method_field('GET'); ?>
                        <?php echo e(csrf_field()); ?>

                        <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Editar Perfil</button>
                    </form>
                    <div class="dropdown-divider"></div>
                    <form action="<?php echo e(url('logout')); ?>" class="form-inline justify-content-center" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <button class="btn btn-outline-light " type="submit">Cerrar Sesión</button>
                    </form>
                </div>
            </li>

        <?php else: ?>
            <form action="<?php echo e(url('login')); ?>" class="form-inline my-2 my-lg-0" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo method_field('GET'); ?>
                <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Iniciar Sesión</button>
            </form>
        <?php endif; ?>
    </div>
</nav><?php /**PATH /home/hojbdyav/laravel/resources/views/navbar/navbar.blade.php ENDPATH**/ ?>