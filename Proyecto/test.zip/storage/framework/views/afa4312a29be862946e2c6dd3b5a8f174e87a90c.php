
<?php $__env->startSection('content'); ?>
<div class="container justify-content-center text-center">
    <h1 class="titulo fuenteTitulo  mt-5">Administración</h1>
    <h2 class="titulo fuenteTitulo  mt-5">Tu rol: <?php echo e(Auth()->user()->role); ?></h2>
    <?php if(Auth()->user()->role=="Administrador"): ?>

        <div class="jumbotron overflowPers" style="background-color: rgba(155, 155, 155, .5);">
            <h4 class="display-4">Usted como Administrador puede:</h4>
            <hr class="my-4" style="background-color: white">
            <ul style="text-align: left">
                <li class="poderesRole">Añadir y editar jugadores</li>
                <li class="poderesRole2">Añadir y editar equipos</li>
                <li class="poderesRole3">Añadir noticias</li>
                <li class="poderesRole4">Añadir y editar partidos</li>
                <li class="poderesRole5">Editar y eliminar usuarios</li>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(Auth()->user()->role=="Creador"): ?>
        <div class="jumbotron h-50 overflowPers" style="background-color: rgba(155, 155, 155, .5);">
            <h4 class="display-4">Usted como Creador puede:</h4>
            <hr class="my-4" style="background-color: white">
            <ul style="text-align: left">
                <li class="poderesRole">Añadir y editar jugadores</li>
                <li class="poderesRole2">Añadir y editar equipos</li>
                <li class="poderesRole3">Añadir noticias</li>
                <li class="poderesRole4"><del>Añadir y editar partidos</del></li>
                <li class="poderesRole5"><del>Editar y eliminar usuarios</del></li>
            </ul>
        </div>
    <?php endif; ?>
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-6 borderAdministration">
                <h5 class="titulo fuenteTitulo mt-1">Usuarios</h5>
                <hr class="estilosHrAdministration ">
                <div class="row">
                    <?php if(Auth()->user()->role=="Creador"): ?>
                        <div class="col-md-12 mt-1 mb-3">
                            <a href="<?php echo e(url('/adminUsers')); ?>"><button class="btn btn-success borderAdministrationButton disabled" type="submit" disabled>Editar Usuarios</button></a>
                        </div>
                    <?php else: ?>
                        <div class="col-md-12 mt-1 mb-3">
                            <a href="<?php echo e(url('/adminUsers')); ?>"><button class="btn btn-success borderAdministrationButton" type="submit">Editar Usuarios</button></a>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
            <div class="col-md-6 borderAdministration">
                <h5 class="titulo fuenteTitulo mt-1">Equipos</h5>
                <hr class="estilosHrAdministration ">
                <div class="row">
                    <div class="col-md-6 mt-1 mb-3">
                        <a href="<?php echo e(url('/clubes')); ?>"><button class="btn btn-success borderAdministrationButton" type="submit">Ver Equipos</button></a>
                    </div>
                    <div class="col-md-6 mt-1 mb-3">
                        <a href="<?php echo e(url('/addTeam')); ?>"><button class="btn btn-success borderAdministrationButton" type="submit">Añadir Equipos</button></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 borderAdministration">
                <h5 class="titulo fuenteTitulo mt-1">Jugadores</h5>
                <hr class="estilosHrAdministration ">
                <div class="row">
                    <div class="col-md-6 mt-1 mb-3">
                        <a href="<?php echo e(url('/jugadores')); ?>"><button class="btn btn-success borderAdministrationButton" type="submit">Ver Jugadores</button></a>
                    </div>
                    <div class="col-md-6 mt-1 mb-3">
                        <a href="<?php echo e(url('/addPlayer')); ?>"><button class="btn btn-success borderAdministrationButton" type="submit">Añadir jugadores</button></a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 borderAdministration">
                <h5 class="titulo fuenteTitulo mt-1">Noticias</h5>
                <hr class="estilosHrAdministration ">
                <div class="row">
                    <div class="col-md-6 mt-1 mb-3">
                        <a href="<?php echo e(url('/')); ?>"><button class="btn btn-success borderAdministrationButton" type="submit">Ver Noticias</button></a>
                    </div>
                    <div class="col-md-6 mt-1 mb-3">
                        <a href="<?php echo e(url('/addNotice')); ?>"><button class="btn btn-success borderAdministrationButton" type="submit">Añadir Noticias</button></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">

            <div class="col-md-12 borderAdministration">
                <h5 class="titulo fuenteTitulo mt-1">Partidos</h5>
                <hr class="estilosHrAdministration ">
                <div class="row">
                    <?php if(Auth()->user()->role=="Creador"): ?>
                        <div class="col-md-4 mt-1 mb-3">
                            <a href="<?php echo e(url('/addMatch/false/madrid')); ?>"><button class="btn btn-success borderAdministrationButton disabled" type="submit" disabled>Añadir Partidos Madrid</button></a>
                        </div>
                        <div class="col-md-4 mt-1 mb-3">
                            <a href="<?php echo e(url('/addMatch/false/barcelona')); ?>"><button class="btn btn-success borderAdministrationButton disabled" type="submit" disabled>Añadir Partidos Barcelona</button></a>
                        </div>
                        <div class="col-md-4 mt-1 mb-3">
                            <a href="<?php echo e(url('/matches')); ?>"><button class="btn btn-success borderAdministrationButton disabled" type="submit" disabled>Ver Partidos</button></a>
                        </div>
                        <?php else: ?>
                        <div class="col-md-4 mt-1 mb-3">
                            <a href="<?php echo e(url('/addMatch/false/madrid')); ?>"><button class="btn btn-success borderAdministrationButton" type="submit">Añadir Partidos Madrid</button></a>
                        </div>
                        <div class="col-md-4 mt-1 mb-3">
                            <a href="<?php echo e(url('/addMatch/false/barcelona')); ?>"><button class="btn btn-success borderAdministrationButton" type="submit">Añadir Partidos Barcelona</button></a>
                        </div>
                        <div class="col-md-4 mt-1 mb-3">
                            <a href="<?php echo e(url('/matches')); ?>"><button class="btn btn-success borderAdministrationButton" type="submit">Ver Partidos</button></a>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hojbdyav/laravel/resources/views/administration.blade.php ENDPATH**/ ?>