<div style="background-color: #020f3c;width: 100%;height: 100%">
<p style="font-family: Verdana;color: aqua;text-align: center">Vemos que te has perdido, para regresar a inicio, <a style="color: white;text-decoration: none" href="{{url('/')}}">pulse aquí</a></p>
</div>