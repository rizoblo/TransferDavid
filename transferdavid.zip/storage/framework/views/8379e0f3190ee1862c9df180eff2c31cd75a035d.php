<?php $__env->startSection('content'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/css/styles.css')); ?>">
    <div class="overflowPers text-white justify-content-center margenCajaPartidos34">
        <div class="col-md-12">
            <h1 class="fuenteTitulo text-center mt-3 mb-1 backGroundCabeceras">Partidos</h1>

            <div class="row">
                <div class="col-md-2 col-sm-12 mt-5 justify-content-start ml-5" style="margin-right: 8%">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="selectCompeticiones">Escoja competición:</label>
                            <select class="form-control text-white bg-info" style="width: 350px" id="selectCompeticiones" name="selectCompeticiones">
                                <?php $__currentLoopData = $ligas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($ligaSeleccionada)): ?>
                                        <?php if($ligaSeleccionada==$liga->id): ?>
                                            <option value="<?php echo e($liga->id); ?>" selected="selected"><?php echo e($liga->name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($liga->id); ?>"><?php echo e($liga->name); ?></option>
                                        <?php endif; ?>
                                        <?php else: ?>
                                        <option value="<?php echo e($liga->id); ?>"><?php echo e($liga->name); ?></option>
                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="selectEquipos">Escoja equipo:</label>
                            <select class="form-control text-white bg-info" style="width: 350px" id="selectEquipos" name="selectEquipos">
                                <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($equipoSeleccionado)): ?>
                                        <?php if($equipoSeleccionado==$equipo->id): ?>
                                            <option value="<?php echo e($equipo->id); ?>" selected="selected"><?php echo e($equipo->name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($equipo->id); ?>"><?php echo e($equipo->name); ?></option>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <option value="<?php echo e($equipo->id); ?>"><?php echo e($equipo->name); ?></option>
                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="selectEstadio">Escoja estadio:</label>
                            <select class="form-control text-white bg-info" style="width: 350px" id="selectEstadio" name="selectEstadio">
                                <?php if(isset($estadioSeleccionado)): ?>
                                    <?php if($estadioSeleccionado=="Todos"): ?>
                                        <option selected="selected">Todos</option>
                                        <option>Local</option>
                                        <option>Visitante</option>
                                    <?php endif; ?>
                                    <?php if($estadioSeleccionado=="Local"): ?>
                                        <option>Todos</option>
                                        <option selected="selected">Local</option>
                                        <option>Visitante</option>
                                    <?php endif; ?>
                                    <?php if($estadioSeleccionado=="Visitante"): ?>
                                        <option>Todos</option>
                                        <option>Local</option>
                                        <option selected="selected">Visitante</option>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <option>Todos</option>
                                    <option>Local</option>
                                    <option>Visitante</option>
                                <?php endif; ?>

                            </select>
                            <label for="selectJornada">Escoja jornada:</label>
                            <select class="form-control text-white bg-info" style="width: 350px" id="selectJornada" name="selectJornada">
                                <option>Todas</option>
                                <?php $__currentLoopData = $jornadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jornada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($jornadaSeleccionada)): ?>
                                        <?php if($jornadaSeleccionada==$jornada->journey): ?>
                                            <option selected="selected"><?php echo e($jornada->journey); ?></option>
                                        <?php else: ?>
                                            <option><?php echo e($jornada->journey); ?></option>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <option><?php echo e($jornada->journey); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <button class="btn btn-info mt-3" type="submit" name="filtrar">Filtrar</button>
                        </div>
                    </form>
                    <?php if(Auth()->check()): ?>
                        <?php if(Auth()->user()->role=="Administrador"): ?>
                            <a href="<?php echo e(url('/addMatch/false')); ?>"><button class="btn btn-info mb-4" type="submit" name="filtrar">Añadir Partido</button></a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                <div class="col-md-8 col-sm-12 table-responsive ml-5" style="max-height: 513px !important;">
                    <table class="table table-bordered fuenteBlanca mt-5">
                        <thead class="thead-light">
                        <tr class="text-center">
                            <th scope="col">Jornada</th>
                            <th scope="col" colspan="2">Local</th>
                            <th scope="col" colspan="3">Resultado</th>
                            <th scope="col" colspan="2">Visitante</th>
                            <th scope="col">Edición</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(isset($arrayPartidos)): ?>

                            <?php $__currentLoopData = $arrayPartidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$partido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($partido->journey); ?></td>

                                    <?php if($partido->id_team_local!=$idMadrid): ?>
                                        <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($infoContrincantes[$key][0]->image)); ?>"></td>
                                        <td><?php echo e($infoContrincantes[$key][0]->name); ?></td>
                                    <?php else: ?>
                                        <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($partido->image)); ?>"></td>
                                        <td><?php echo e($partido->name); ?></td>
                                    <?php endif; ?>
                                    <td style="font-size: 30px;min-width: 98px;" colspan="3"><?php echo e($partido->score_local); ?> - <?php echo e($partido->score_visitor); ?></td>
                                    <?php if($partido->id_team_visitor!=$idMadrid): ?>
                                        <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($infoContrincantes[$key][0]->image)); ?>"></td>
                                        <td><?php echo e($infoContrincantes[$key][0]->name); ?></td>
                                    <?php else: ?>
                                        <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($partido->image)); ?>"></td>
                                        <td><?php echo e($partido->name); ?></td>
                                    <?php endif; ?>

                                    <td>
                                        <form action="<?php echo e(url('/editMatch')); ?>" method="POST" name="editarPartidoList">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" value="<?php echo e($arrayPartidos[$key]->id); ?>" name="guardarIdPartidoEditar">
                                            <?php if(Auth()->check()): ?>
                                                <?php if(Auth()->user()->role=="Administrador"): ?>
                                                    <button type="submit" class="btn btn-warning">Editar</button>
                                                <?php else: ?>
                                                    <button type="submit" class="btn btn-warning disabled" disabled>Editar</button>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <button type="submit" class="btn btn-warning disabled" disabled>Editar</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(isset($partidosLigaLocal)): ?>
                            <?php $__currentLoopData = $partidosLigaLocal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$partido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($partido->journey); ?></td>

                                    <?php if($partido->id_team_local!=$equipoSeleccionado): ?>
                                        <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($infoContrincantes[$key][0]->image)); ?>"></td>
                                        <td><?php echo e($infoContrincantes[$key][0]->name); ?></td>
                                    <?php else: ?>
                                        <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($partido->image)); ?>"></td>
                                        <td><?php echo e($partido->name); ?></td>
                                    <?php endif; ?>
                                    <td style="font-size: 30px;min-width: 98px;" colspan="3"><?php echo e($partido->score_local); ?> - <?php echo e($partido->score_visitor); ?></td>
                                    <?php if($partido->id_team_visitor!=$equipoSeleccionado): ?>
                                        <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($infoContrincantes[$key][0]->image)); ?>"></td>
                                        <td><?php echo e($infoContrincantes[$key][0]->name); ?></td>
                                    <?php else: ?>
                                        <td class="text-center" style="min-width: 75px"><img class="tamanioFotoClubTabla" src="<?php echo e(asset($partido->image)); ?>"></td>
                                        <td><?php echo e($partido->name); ?></td>
                                    <?php endif; ?>

                                    <td>
                                        <form action="<?php echo e(url('/editMatch')); ?>" method="POST" name="editarPartidoList">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" value="<?php echo e($partidosLigaLocal[$key]->id); ?>" name="guardarIdPartidoEditar">
                                            <?php if(Auth()->check()): ?>
                                                <?php if(Auth()->user()->role=="Administrador"): ?>
                                                    <button type="submit" class="btn btn-warning">Editar</button>
                                                <?php else: ?>
                                                    <button type="submit" class="btn btn-warning disabled" disabled>Editar</button>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <button type="submit" class="btn btn-warning disabled" disabled>Editar</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TransferDavid\resources\views/matchesList.blade.php ENDPATH**/ ?>