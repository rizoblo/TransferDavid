
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/styles.css')); ?>">

    <h1 class="fuenteTitulo text-center mt-5 mb-5" name="bienvenidaAddMatchMadrid">Datos del partido a añadir</h1>

    <div class="container fuenteBlanca w-50">
        <form action="" method="POST" class="formAddMatch">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="localTeam" class="fuenteBlanca">Equipo local:</label>
                <select class="form-control" id="localTeam" name="localTeamAddMatch" value="<?php echo e(old('localTeam')); ?>">
                    <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
ç                            <option value="<?php echo e($club->id); ?>"><?php echo e($club->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="visitorTeam" class="fuenteBlanca">Equipo visitante:</label>
                <select class="form-control" id="visitorTeam" name="visitorTeamAddMatch" value="<?php echo e(old('visitorTeam')); ?>">
                    <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($club->id); ?>" ><?php echo e($club->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="league" class="fuenteBlanca">Liga:</label>
                <select class="form-control" id="league" name="league" value="<?php echo e(old('league')); ?>">
                    <?php $__currentLoopData = $ligas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($liga->id); ?>"><?php echo e($liga->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <?php if(isset($existenciaPartido)): ?>
            
                <?php if($existenciaPartido=="localExiste"): ?>
                    <p style="color:red">*Esa jornada ya existe en esa liga para el equipo local*</p>
                <?php endif; ?>
                <?php if($existenciaPartido=="visitanteExiste"): ?>
                <p style="color:red">*Esa jornada ya existe en esa liga para el equipo visitante*</p>
                <?php endif; ?>
                <?php if($existenciaPartido=="ambosExisten"): ?>
                <p style="color:red">*Esa jornada ya existe para ambos equipos en esa liga*</p>
                <?php endif; ?>
            <?php endif; ?>  
            <div class="form-group">
                <label for="journey" class="fuenteBlanca">Jornada:</label>
                <input type="number" class="form-control" name="journey" value=" <?php echo e(old('journey')); ?> " required min="1" id="journey" >
            </div>

            <div class="form-group">
                <label for="scoreLocal" class="fuenteBlanca">Marcador Local:</label>
                <input type="number" class="form-control" name="scoreLocal" value=" <?php echo e(old('scoreLocal')); ?> " required id="scoreLocal"  min="0">
            </div>
            <div class="form-group">
                <label for="scoreVisitor" class="fuenteBlanca">Marcador Visitante:</label>
                <input type="number" class="form-control" name="scoreVisitor" value=" <?php echo e(old('scoreVisitor')); ?> " required id="scoreVisitor"  min="0" >
            </div>


            <button class="btn btn-success" type="submit" name="guardarPartidoAddMatch">Guardar</button>
        </form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hojbdyav/laravel/resources/views/addMatch.blade.php ENDPATH**/ ?>