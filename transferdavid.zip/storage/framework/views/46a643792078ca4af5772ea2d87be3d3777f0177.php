<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/styles.css')); ?>">
    <div class="col-md-12 justify-content-center text-center" >
        <h1 class="fuenteTitulo mt-5 backGroundCabeceras">Clubes</h1>
        <div class="container">
            <div class="col-md-12 mt-5 mb-5">
                <div class="row prueba">
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mt-5">
                                <a href="<?php echo e(url('infoClub/'.$team->id)); ?>">
                                    <img class="img-fluid" style="max-height:80px !Important" src="<?php echo e($team->image); ?>"></a>
                            <h6 class="fuenteBlanca"><?php echo e($team->name); ?></h6>
                            <div class="row mt-4">
                                <div class="col-md-12">
                                    <?php if(Auth::check()): ?>
                                        <?php if(Auth()->user()->role=="Estándar"): ?>
                                            <a class="btn btn-success disabled" style="color:white" href="<?php echo e(url("/editClub/".$team->id)); ?>" >Editar</a>
                                            <a class="btn btn-danger disabled" href="<?php echo e(url("/clubes/".$team->id)); ?>" >Eliminar</a>

                                        <?php else: ?>
                                            <?php if($team->name=="Real Madrid C.F" || $team->name=="F.C Barcelona"): ?>
                                                <a class="btn btn-success" style="color:white" href="<?php echo e(url("/editClub/".$team->id)); ?>">Editar</a>
                                                <a class="btn btn-danger disabled" href="<?php echo e(url("/clubes/".$team->id)); ?>" >Eliminar</a>
                                            <?php else: ?>
                                                <a class="btn btn-success" style="color:white" href="<?php echo e(url("/editClub/".$team->id)); ?>">Editar</a>
                                                <a class="btn btn-danger" href="<?php echo e(url("/clubes/".$team->id)); ?>">Eliminar</a>
                                            <?php endif; ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TransferDavid\resources\views/clubes.blade.php ENDPATH**/ ?>