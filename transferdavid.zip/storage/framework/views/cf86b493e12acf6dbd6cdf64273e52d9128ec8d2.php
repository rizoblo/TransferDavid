
<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/styles.css')); ?>">
    <h1 class="fuenteTitulo text-center mt-5 mb-5">Datos del Usuario</h1>
    <div class="container w-50">
        <form action="" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name" class="fuenteBlanca">Nombre</label>
                <input type="text" class="form-control" name="name" id="name" value=" <?php echo e($user->name); ?>" placeholder="<?php echo e($user->name); ?>" maxlength="30" style="width:40% !important">
            </div>
            <div class="form-group">
                <label for="last_name" class="fuenteBlanca">Apellido 1</label>
                <input type="text" class="form-control" name="last_name" id="last_name" value=" <?php echo e($user->last_name); ?>" placeholder="<?php echo e($user->last_name); ?>" maxlength="30" style="width:40% !important">
            </div>
            <div class="form-group">
                <label for="last_name2" class="fuenteBlanca">Apellido 2</label>
                <input type="text" class="form-control" name="last_name2" id="last_name2" value=" <?php echo e($user->last_name2); ?>" placeholder="<?php echo e($user->last_name2); ?>" maxlength="30" style="width:40% !important">
            </div>
            <div class="form-group">
                <label for="email" class="fuenteBlanca">Email address</label>
                <input type="email" class="form-control" name="email" value=" <?php echo e($user->email); ?> " id="email" placeholder="<?php echo e($user->email); ?>" maxlength="60" style="width:73% !important">
            </div>
            <div class="form-group">
                <label for="passActual" class="fuenteBlanca">Contraseña Actual *Rellene este campo si desea cambiar la contraseña*</label>
                <input type="password" class="form-control <?php $__errorArgs = ['passActual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" maxlength="70" style="width:48% !important" id="passActual" name="passActual">
                <?php $__errorArgs = ['passActual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div class="form-group">
                <label for="Contraseña1" class="fuenteBlanca">Nueva contraseña</label>
                <input type="password" class="form-control <?php $__errorArgs = ['Contraseña1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="Contraseña1" id="Contraseña1" maxlength="70" style="width:48% !important">
                <?php $__errorArgs = ['Contraseña1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="Contraseña2" class="fuenteBlanca">Repita contraseña</label>
                <input type="password" class="form-control" name="Contraseña2" id="Contraseña2" maxlength="70" style="width:48% !important">
            </div>
            <div class="form-group">
                <label for="fav_team" class="fuenteBlanca">Equipo favorito</label>
                <select class="form-control" style="width:30% !important" id="fav_team" name="fav_team">
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($team->id == $user->fav_team): ?>
                            <option value="<?php echo e($team->id); ?>" selected="selected"><?php echo e($team->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="role" class="fuenteBlanca">Rol</label>
                <select class="form-control" style="width:27% !important" id="role" name="role">
                    <?php if($variable=="noAdmin"): ?>
                        <?php if(Auth()->user()->role == "Estándar"): ?>
                            <option value="Estándar" selected="selected">Estándar</option>
                        <?php endif; ?>
                        <?php if(Auth()->user()->role == "Creador"): ?>
                            <option value="Creador" selected="selected">Creador</option>
                        <?php endif; ?>
                        <?php if(Auth()->user()->role == "Administrador"): ?>
                            <option value="Administrador" selected="selected">Administrador</option>
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($user->role=="Estándar"): ?>
                            <option value="Estándar" selected="selected">Estándar</option>
                            <option value="Creador">Creador</option>
                            <option value="Administrador">Administrador</option>
                        <?php endif; ?>
                        <?php if($user->role=="Creador"): ?>
                            <option value="Estándar">Estándar</option>
                            <option value="Creador" selected="selected">Creador</option>
                            <option value="Administrador">Administrador</option>
                        <?php endif; ?>
                        <?php if($user->role=="Administrador"): ?>
                            <option value="Estándar">Estándar</option>
                            <option value="Creador">Creador</option>
                            <option value="Administrador" selected="selected">Administrador</option>
                        <?php endif; ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="user_description" class="fuenteBlanca">Descripción del Usuario</label>
                <textarea class="form-control" name="user_description" id="user_description" rows="3" value=" <?php echo e($user->user_description); ?>" maxlength="200" required><?php echo e($user->user_description); ?></textarea>
            </div>
            <button class="btn btn-success" type="submit" name="guardar">Guardar</button>
        </form>
        <br>
        <form action="" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <button type="submit" class="btn btn-danger" name="eliminar">Eliminar Cuenta</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hojbdyav/laravel/resources/views/editUser.blade.php ENDPATH**/ ?>