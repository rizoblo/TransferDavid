
<?php $__env->startSection('content'); ?>
    <h1 class="fuenteTitulo text-center mt-5 mb-5">Añadir Jugador</h1>
    <div class="container w-50">
        <form action="" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="namePlayer" class="fuenteBlanca">Nombre del Jugador:</label>
                <input type="text" class="form-control" maxlength="40" name="namePlayer" id="namePlayer" value="<?php echo e(old('namePlayer')); ?>" placeholder="Escriba el nombre del Jugador" required>
            </div>
            <div class="form-group">
                <label for="lastnamePlayer" class="fuenteBlanca">Apellido del Jugador:</label>
                <input type="text" class="form-control" maxlength="40" name="lastnamePlayer" id="lastnamePlayer" value="<?php echo e(old('lastnamePlayer')); ?>" placeholder="Escriba el apellido del Jugador" required>
            </div>
            <div class="form-group">
                <label for="valuePlayer" class="fuenteBlanca">Valor de Mercado:</label>
                <input type="number" class="form-control" min="1" max="1000000000" name="valuePlayer" id="valuePlayer" value="<?php echo e(old('valuePlayer')); ?>" placeholder="Inserte valor del Jugador" required>
            </div>
            <div class="form-group">
                <label for="positionPlayer" class="fuenteBlanca">Posición del Jugador:</label>
                <select class="form-control" id="positionPlayer" name="positionPlayer" value="<?php echo e(old('positionPlayer')); ?>" required>
                    <option selected="selected">Delantero</option>
                    <option>Centrocampista</option>
                    <option>Defensa</option>
                    <option>Portero</option>
                </select>
            </div>
            <div class="form-group">
                <label for="teamPlayer" class="fuenteBlanca">Equipo del Jugador:</label>
                <select class="form-control" id="teamPlayer" name="teamPlayer" value="<?php echo e(old('teamPlayer')); ?>" required>
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="image" class="fuenteBlanca">Seleccione la imagen del Jugador:</label><br>
                <input type="file" class="fuenteBlanca" class="form-control-file" id="image" name="image" value="<?php echo e(old('image')); ?>" accept="image/*" required>
            </div>
            <button class="btn btn-success" type="submit" name="guardar">Guardar</button>
        </form>
        <br>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hojbdyav/laravel/resources/views/addPlayer.blade.php ENDPATH**/ ?>